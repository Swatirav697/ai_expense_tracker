# AI Expense Tracker

A beginner-friendly Flask project that records expenses, suggests categories using a small machine-learning text classifier, and displays spending summaries.

## Features
- Add and delete expenses
- AI-assisted category suggestion from the expense title and notes
- Dashboard with total spending, current-month spending and transaction count
- Category-wise spending chart
- SQLite database created automatically

## Run on Windows
1. Install Python 3.10 or newer.
2. Extract the ZIP file.
3. Double-click `run_windows.bat`, or open a terminal in this folder and run:
   ```bash
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
   ```
4. Open http://127.0.0.1:5000 in your browser.

## Run on macOS / Linux
```bash
chmod +x run_mac_linux.sh
./run_mac_linux.sh
```
Then open http://127.0.0.1:5000.

## Notes
- The database file `expenses.db` is generated automatically on first run.
- The ML model is trained from a small sample dataset in `ai_categorizer.py`; this is a demo classifier, not a production-grade financial model.
- If scikit-learn is unavailable, the app uses a keyword-based fallback.
- For a real deployment, set a strong secret key, add authentication, validate dates, add tests and use environment variables for configuration.
