"""Lightweight ML expense categorizer.

If scikit-learn is installed, a TF-IDF + Logistic Regression model is trained
from the small example dataset below. Otherwise, a keyword-based fallback
keeps the app runnable without machine-learning packages.
"""
TRAINING_DATA = [
    ("grocery vegetables supermarket milk bread fruits", "Food"),
    ("restaurant lunch dinner pizza coffee cafe", "Food"),
    ("uber taxi bus train petrol fuel metro", "Transport"),
    ("electricity water internet mobile phone bill", "Bills"),
    ("rent house apartment maintenance", "Housing"),
    ("doctor medicine pharmacy hospital", "Health"),
    ("movie concert game subscription", "Entertainment"),
    ("shirt shoes clothes shopping mall", "Shopping"),
    ("course book tuition education college", "Education"),
    ("flight hotel trip vacation travel", "Travel"),
]

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import make_pipeline

    _texts = [x[0] for x in TRAINING_DATA]
    _labels = [x[1] for x in TRAINING_DATA]
    _model = make_pipeline(
        TfidfVectorizer(ngram_range=(1, 2), stop_words="english"),
        LogisticRegression(max_iter=1000)
    )
    _model.fit(_texts, _labels)
except Exception:
    _model = None

KEYWORDS = {
    "Food": ["grocery", "vegetable", "milk", "bread", "restaurant", "lunch", "dinner", "pizza", "coffee", "food"],
    "Transport": ["uber", "taxi", "bus", "train", "petrol", "fuel", "metro", "auto"],
    "Bills": ["electricity", "water", "internet", "mobile", "phone", "bill", "wifi"],
    "Housing": ["rent", "house", "apartment", "maintenance"],
    "Health": ["doctor", "medicine", "pharmacy", "hospital", "health"],
    "Entertainment": ["movie", "concert", "game", "subscription", "netflix"],
    "Shopping": ["shirt", "shoes", "clothes", "shopping", "mall"],
    "Education": ["course", "book", "tuition", "education", "college"],
    "Travel": ["flight", "hotel", "trip", "vacation", "travel"],
}

def categorize_expense(text):
    text = (text or "").lower().strip()
    if _model is not None:
        probabilities = _model.predict_proba([text])[0]
        index = probabilities.argmax()
        return _model.classes_[index], round(float(probabilities[index]) * 100)
    scores = {category: sum(word in text for word in words) for category, words in KEYWORDS.items()}
    best = max(scores, key=scores.get)
    if scores[best] == 0:
        return "Other", 55
    return best, min(95, 60 + scores[best] * 10)
