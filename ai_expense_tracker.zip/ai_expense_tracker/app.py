from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import sqlite3
from pathlib import Path
from datetime import date
from ai_categorizer import categorize_expense

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB_PATH = Path(__file__).with_name("expenses.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                amount REAL NOT NULL CHECK(amount > 0),
                category TEXT NOT NULL,
                expense_date TEXT NOT NULL,
                notes TEXT DEFAULT ''
            )
        """)
        db.commit()

@app.route("/")
def index():
    with get_db() as db:
        expenses = db.execute(
            "SELECT * FROM expenses ORDER BY expense_date DESC, id DESC"
        ).fetchall()
        total = db.execute("SELECT COALESCE(SUM(amount), 0) FROM expenses").fetchone()[0]
        month_total = db.execute(
            "SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE strftime('%Y-%m', expense_date)=?",
            (date.today().strftime("%Y-%m"),)
        ).fetchone()[0]
        count = db.execute("SELECT COUNT(*) FROM expenses").fetchone()[0]
        category_rows = db.execute(
            "SELECT category, SUM(amount) AS total FROM expenses GROUP BY category ORDER BY total DESC"
        ).fetchall()
    categories = [{"name": r["category"], "total": round(r["total"], 2)} for r in category_rows]
    return render_template("index.html", expenses=expenses, total=total,
                           month_total=month_total, count=count, categories=categories,
                           today=date.today().isoformat())

@app.route("/add", methods=["POST"])
def add_expense():
    title = request.form.get("title", "").strip()
    amount_text = request.form.get("amount", "").strip()
    expense_date = request.form.get("expense_date", "").strip()
    notes = request.form.get("notes", "").strip()
    if not title or not amount_text or not expense_date:
        flash("Please fill in the title, amount and date.", "error")
        return redirect(url_for("index"))
    try:
        amount = float(amount_text)
        if amount <= 0:
            raise ValueError
    except ValueError:
        flash("Enter a valid amount greater than zero.", "error")
        return redirect(url_for("index"))

    category, confidence = categorize_expense(title + " " + notes)
    with get_db() as db:
        db.execute(
            "INSERT INTO expenses (title, amount, category, expense_date, notes) VALUES (?, ?, ?, ?, ?)",
            (title, amount, category, expense_date, notes)
        )
        db.commit()
    flash(f"Expense added. AI suggested category: {category} ({confidence}% confidence).", "success")
    return redirect(url_for("index"))

@app.route("/delete/<int:expense_id>", methods=["POST"])
def delete_expense(expense_id):
    with get_db() as db:
        db.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
        db.commit()
    flash("Expense deleted.", "success")
    return redirect(url_for("index"))

@app.route("/api/summary")
def api_summary():
    with get_db() as db:
        rows = db.execute(
            "SELECT category, SUM(amount) AS total FROM expenses GROUP BY category ORDER BY total DESC"
        ).fetchall()
    return jsonify([{"category": r["category"], "total": round(r["total"], 2)} for r in rows])

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
